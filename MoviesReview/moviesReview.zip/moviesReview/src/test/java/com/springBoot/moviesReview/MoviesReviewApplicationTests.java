package com.springBoot.moviesReview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
