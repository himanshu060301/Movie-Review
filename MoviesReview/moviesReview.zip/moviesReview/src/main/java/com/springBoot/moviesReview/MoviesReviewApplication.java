package com.springBoot.moviesReview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesReviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesReviewApplication.class, args);
	}

}
